<?php
for ($i = 1899; $i < 2020; $i++){
    $link = "https://www.google.com/search?q=";
    $linkCool = $link . $i;
    ?> <a href="<?=$linkCool ?>"><?= $i ?></a>
        <br>
        <?
}
?>