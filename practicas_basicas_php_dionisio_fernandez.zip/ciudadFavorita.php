<html>

<?
$ciudad=htmlspecialchars($_POST['ciudad']);
?>

    <a href='https://www.google.com/search?q=<?=$ciudad?>'> <?=$ciudad?> es tu ciudad favorita </a>
</html>